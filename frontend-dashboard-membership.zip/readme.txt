=== Frontend Dashboard Membership ===
Contributors: vinoth06, buffercode
Tags: dashboard, frontend dashboard, membership
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=7DHAEMST475BY
Requires at least: 4.6
Tested up to: 4.9.8
Stable tag: 1.0
License: GPL V3
License URI: https://www.gnu.org/licenses/gpl-3.0.en.html

Frontend Dashboard membership allows flexible way to create a membership based website.

== Description ==
> #### Notice
> This is a Add-on plugin of [Frontend Dashboard](https://wordpress.org/plugins/frontend-dashboard/), So please install [Frontend Dashboard](https://buffercode.com/plugin/frontend-dashboard) to use this plugin **

Frontend Dashboard membership

== Installation ==
1. Upload the “frontend-dashboard-membership” directory to the plugins directory.
2. Go to the plugins setting page and activate “Frontend Dashboard Membership”
3. Go to Frontend Dashboard | Frontend Dashboard | Membership
4. Do save.

== Frequently Asked Questions ==


== Changelog ==

= v1.0 =
* Public release

== Upgrade Notice ==

== Screenshots ==

