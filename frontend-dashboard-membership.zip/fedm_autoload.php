<?php

/**
 * Autoload Files
 */
require_once BC_FED_M_PLUGIN_DIR . '/functions.php';
require_once BC_FED_M_PLUGIN_DIR . '/shortcodes/membership.php';
require_once BC_FED_M_PLUGIN_DIR . '/admin/FED_M_Menu.php';
require_once BC_FED_M_PLUGIN_DIR . '/admin/FED_M_Templates.php';
require_once BC_FED_M_PLUGIN_DIR . '/admin/FED_M_Membership.php';
require_once BC_FED_M_PLUGIN_DIR . '/admin/templates/FED_M_Template1.php';